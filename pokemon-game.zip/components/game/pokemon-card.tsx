"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import PokemonSprite from "./pokemon-sprite"
import type { Pokemon } from "@/lib/game-types"
import { cn } from "@/lib/utils"

interface PokemonCardProps {
  pokemon: Pokemon
  onClick?: () => void
  showStats?: boolean
  className?: string
}

export default function PokemonCard({ pokemon, onClick, showStats = true, className }: PokemonCardProps) {
  const experiencePercent = (pokemon.experience / pokemon.experienceToNext) * 100

  return (
    <Card
      className={cn(
        "cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105",
        "bg-gradient-to-br from-card to-card/80",
        className,
      )}
      onClick={onClick}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold text-balance">{pokemon.name}</CardTitle>
          <Badge variant="secondary" className="font-mono">
            Lv.{pokemon.level}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Pokémon Sprite */}
        <div className="flex justify-center">
          <PokemonSprite pokemon={pokemon} size="medium" />
        </div>

        {/* HP Bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span>HP</span>
            <span className="font-mono">
              {pokemon.hp}/{pokemon.maxHp}
            </span>
          </div>
          <Progress value={(pokemon.hp / pokemon.maxHp) * 100} className="h-2" />
        </div>

        {/* Experience Bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span>EXP</span>
            <span className="font-mono">
              {pokemon.experience}/{pokemon.experienceToNext}
            </span>
          </div>
          <Progress value={experiencePercent} className="h-2" />
        </div>

        {/* Stats */}
        {showStats && (
          <div className="grid grid-cols-3 gap-2 text-sm">
            <div className="text-center">
              <div className="font-semibold text-red-500">{pokemon.attack}</div>
              <div className="text-muted-foreground">ATK</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-blue-500">{pokemon.defense}</div>
              <div className="text-muted-foreground">DEF</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-green-500">{pokemon.speed}</div>
              <div className="text-muted-foreground">SPD</div>
            </div>
          </div>
        )}

        {/* Abilities */}
        <div className="space-y-1">
          <div className="text-sm font-semibold">Abilities:</div>
          <div className="flex flex-wrap gap-1">
            {pokemon.abilities.map((ability) => (
              <Badge key={ability.id} variant="outline" className="text-xs">
                {ability.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Evolution indicator */}
        {pokemon.evolutionLevel && pokemon.level >= pokemon.evolutionLevel && (
          <div className="text-center">
            <Badge className="bg-yellow-500 text-yellow-900 animate-pulse">Ready to Evolve!</Badge>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
