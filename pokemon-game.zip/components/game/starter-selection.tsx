"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import PokemonSprite from "./pokemon-sprite"
import { gameEngine } from "@/lib/game-engine"
import { getStarterPokemon } from "@/lib/pokemon-data"
import type { Pokemon } from "@/lib/game-types"

export default function StarterSelection() {
  const [selectedPokemon, setSelectedPokemon] = useState<Pokemon | null>(null)
  const [starterPokemon] = useState(getStarterPokemon())
  const [isConfirming, setIsConfirming] = useState(false)

  const handlePokemonSelect = (pokemon: Pokemon) => {
    setSelectedPokemon(pokemon)
    gameEngine.playSound("menu-select")
  }

  const handleConfirm = () => {
    if (!selectedPokemon) return

    setIsConfirming(true)
    gameEngine.playSound("pokemon-capture")

    setTimeout(() => {
      gameEngine.selectStarterPokemon(selectedPokemon.id)
      setIsConfirming(false)
    }, 2000)
  }

  return (
    <div className="w-full h-screen bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4 text-balance drop-shadow-lg">Choose Your First Partner!</h1>
          <p className="text-white/90 text-lg">This Pokémon will be your companion on your journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {starterPokemon.map((pokemon) => (
            <Card
              key={pokemon.id}
              className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                selectedPokemon?.id === pokemon.id
                  ? "ring-4 ring-yellow-400 bg-yellow-400/10 shadow-2xl"
                  : "hover:shadow-xl"
              } bg-white/90 backdrop-blur-sm`}
              onClick={() => handlePokemonSelect(pokemon)}
            >
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-balance">{pokemon.name}</CardTitle>
                <Badge className="mx-auto w-fit text-sm">{pokemon.type.toUpperCase()}</Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-center">
                  <PokemonSprite pokemon={pokemon} size="large" animated={selectedPokemon?.id === pokemon.id} />
                </div>

                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-center">
                    <div className="font-bold text-red-500 text-lg">{pokemon.attack}</div>
                    <div className="text-muted-foreground">Attack</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-blue-500 text-lg">{pokemon.defense}</div>
                    <div className="text-muted-foreground">Defense</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-green-500 text-lg">{pokemon.speed}</div>
                    <div className="text-muted-foreground">Speed</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="font-semibold">Starting Abilities:</div>
                  <div className="flex flex-wrap gap-1">
                    {pokemon.abilities.map((ability) => (
                      <Badge key={ability.id} variant="outline" className="text-xs">
                        {ability.name}
                      </Badge>
                    ))}
                  </div>
                </div>

                {selectedPokemon?.id === pokemon.id && (
                  <div className="text-center p-2 bg-yellow-100 rounded-lg">
                    <p className="text-sm font-medium text-yellow-800">Selected!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {selectedPokemon && (
          <div className="text-center">
            <Button
              onClick={handleConfirm}
              disabled={isConfirming}
              className="px-8 py-4 text-xl font-bold bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg"
            >
              {isConfirming ? "Catching your partner..." : `Choose ${selectedPokemon.name}!`}
            </Button>
          </div>
        )}

        {isConfirming && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="bg-white p-8 text-center">
              <CardContent>
                <div className="animate-spin w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4" />
                <p className="text-xl font-bold">Catching {selectedPokemon?.name}...</p>
                <p className="text-muted-foreground mt-2">Your adventure is about to begin!</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
