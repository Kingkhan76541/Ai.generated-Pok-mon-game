"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Volume2, VolumeX, Settings } from "lucide-react"
import AnimatedBackground from "./animated-background"
import SoundManager from "./sound-manager"
import { gameEngine } from "@/lib/game-engine"

export default function MainMenu() {
  const [isLoading, setIsLoading] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [musicEnabled, setMusicEnabled] = useState(true)
  const [hasExistingSave, setHasExistingSave] = useState(false)

  useEffect(() => {
    // Check for existing save
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("pokemon-game-save")
      setHasExistingSave(!!saved)
    }
  }, [])

  const handleStartGame = () => {
    setIsLoading(true)
    gameEngine.playSound("menu-select")
    setTimeout(() => {
      gameEngine.setScreen("character-select")
      setIsLoading(false)
    }, 1000)
  }

  const handleContinueGame = () => {
    setIsLoading(true)
    gameEngine.playSound("menu-select")
    if (gameEngine.loadGame()) {
      setTimeout(() => {
        gameEngine.setScreen("world")
        setIsLoading(false)
      }, 1000)
    } else {
      setIsLoading(false)
    }
  }

  const handleShop = () => {
    gameEngine.playSound("menu-select")
    gameEngine.setScreen("shop")
  }

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      <AnimatedBackground type="menu" />
      <SoundManager currentScreen="menu" />

      {/* Main menu content */}
      <div className="relative z-10 w-full max-w-md mx-auto px-4">
        {/* Game logo */}
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold text-white mb-2 text-balance drop-shadow-2xl">
            <span className="bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 bg-clip-text text-transparent">
              CUBE
            </span>
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-green-500 to-purple-500 bg-clip-text text-transparent">
              MONSTERS
            </span>
          </h1>
          <p className="text-white/80 text-lg font-medium">Catch, Train, Battle!</p>
        </div>

        {/* Menu buttons */}
        <Card className="bg-black/20 backdrop-blur-md border-white/20">
          <CardContent className="p-6 space-y-4">
            <Button
              onClick={handleStartGame}
              disabled={isLoading}
              className="w-full h-12 text-lg font-bold bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-0 shadow-lg"
            >
              {isLoading ? "Loading..." : "New Game"}
            </Button>

            {hasExistingSave && (
              <Button
                onClick={handleContinueGame}
                disabled={isLoading}
                className="w-full h-12 text-lg font-bold bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white border-0 shadow-lg"
              >
                Continue
              </Button>
            )}

            <Button
              onClick={handleShop}
              className="w-full h-12 text-lg font-bold bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white border-0 shadow-lg"
            >
              Shop
            </Button>

            <div className="flex gap-2">
              <Button
                onClick={() => setShowSettings(!showSettings)}
                variant="outline"
                size="icon"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <Settings className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => setMusicEnabled(!musicEnabled)}
                variant="outline"
                size="icon"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                {musicEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              </Button>
            </div>

            {showSettings && (
              <Card className="bg-black/40 border-white/20">
                <CardContent className="p-4 space-y-2">
                  <div className="text-white text-sm">
                    <p>Music Volume: {musicEnabled ? "On" : "Off"}</p>
                    <p>Version: 1.0.0</p>
                    <p>Save Data: {hasExistingSave ? "Found" : "None"}</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-white/60 text-sm">
          <p>Use WASD or Arrow Keys to move</p>
          <p>Click to interact with objects</p>
        </div>
      </div>

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-20">
          <div className="text-white text-2xl font-bold animate-pulse">Loading...</div>
        </div>
      )}
    </div>
  )
}
