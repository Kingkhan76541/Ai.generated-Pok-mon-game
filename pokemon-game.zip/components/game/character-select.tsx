"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft } from "lucide-react"
import AnimatedBackground from "./animated-background"
import PokemonSprite from "./pokemon-sprite"
import { gameEngine } from "@/lib/game-engine"
import { getStarterPokemon } from "@/lib/pokemon-data"
import type { Pokemon } from "@/lib/game-types"

const PLAYER_CHARACTERS = [
  {
    id: "ash",
    name: "Ash",
    sprite: "/young-trainer-boy-pixel-art.jpg",
    skill: {
      name: "Quick Reflexes",
      description: "Increases Pokémon capture rate by 15%",
      effect: "capture_boost",
    },
  },
  {
    id: "misty",
    name: "Misty",
    sprite: "/water-trainer-girl-pixel-art.jpg",
    skill: {
      name: "Water Bond",
      description: "Water-type Pokémon gain +10% experience",
      effect: "water_exp_boost",
    },
  },
  {
    id: "brock",
    name: "Brock",
    sprite: "/rock-trainer-boy-pixel-art.jpg",
    skill: {
      name: "Rock Solid",
      description: "Rock-type Pokémon have +5 defense",
      effect: "rock_defense_boost",
    },
  },
  {
    id: "may",
    name: "May",
    sprite: "/contest-trainer-girl-pixel-art.jpg",
    skill: {
      name: "Contest Star",
      description: "Earn 20% more currency from battles",
      effect: "currency_boost",
    },
  },
]

export default function CharacterSelect() {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null)
  const [selectedStarter, setSelectedStarter] = useState<Pokemon | null>(null)
  const [step, setStep] = useState<"character" | "starter">("character")
  const [starterPokemon] = useState(getStarterPokemon())

  const handleCharacterSelect = (characterId: string) => {
    setSelectedCharacter(characterId)
    gameEngine.playSound("menu-select")
    setStep("starter")
  }

  const handleStarterSelect = (pokemon: Pokemon) => {
    setSelectedStarter(pokemon)
    gameEngine.playSound("menu-select")
  }

  const handleConfirm = () => {
    if (!selectedCharacter || !selectedStarter) return

    const character = PLAYER_CHARACTERS.find((c) => c.id === selectedCharacter)
    if (!character) return

    // Update game state with selected character and starter
    const gameState = gameEngine.getGameState()
    gameState.player.name = character.name
    gameState.player.sprite = character.sprite
    gameState.player.skill = character.skill

    gameEngine.selectStarterPokemon(selectedStarter.id)
    gameEngine.playSound("pokemon-capture")
  }

  const handleBack = () => {
    if (step === "starter") {
      setStep("character")
      setSelectedStarter(null)
    } else {
      gameEngine.setScreen("menu")
    }
    gameEngine.playSound("menu-select")
  }

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      <AnimatedBackground type="menu" />

      <div className="relative z-10 w-full max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button onClick={handleBack} variant="outline" className="bg-white/10 border-white/20 text-white">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-white text-balance">
            {step === "character" ? "Choose Your Character" : "Choose Your Starter"}
          </h1>
          <div className="w-20" /> {/* Spacer */}
        </div>

        {step === "character" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {PLAYER_CHARACTERS.map((character) => (
              <Card
                key={character.id}
                className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                  selectedCharacter === character.id
                    ? "ring-2 ring-yellow-400 bg-yellow-400/10"
                    : "bg-black/20 hover:bg-black/30"
                } backdrop-blur-md border-white/20`}
                onClick={() => handleCharacterSelect(character.id)}
              >
                <CardHeader className="text-center">
                  <CardTitle className="text-white text-balance">{character.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <img
                        src={character.sprite || "/placeholder.svg"}
                        alt={character.name}
                        className="w-12 h-12 pixel-art"
                        style={{ imageRendering: "pixelated" }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Badge className="w-full justify-center bg-gradient-to-r from-purple-500 to-pink-500">
                      {character.skill.name}
                    </Badge>
                    <p className="text-white/80 text-sm text-center text-pretty">{character.skill.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {step === "starter" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {starterPokemon.map((pokemon) => (
                <Card
                  key={pokemon.id}
                  className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedStarter?.id === pokemon.id
                      ? "ring-2 ring-yellow-400 bg-yellow-400/10"
                      : "bg-black/20 hover:bg-black/30"
                  } backdrop-blur-md border-white/20`}
                  onClick={() => handleStarterSelect(pokemon)}
                >
                  <CardHeader className="text-center">
                    <CardTitle className="text-white text-balance">{pokemon.name}</CardTitle>
                    <Badge className="mx-auto w-fit">{pokemon.type.toUpperCase()}</Badge>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-center">
                      <PokemonSprite pokemon={pokemon} size="large" />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm text-white">
                      <div className="text-center">
                        <div className="font-semibold text-red-400">{pokemon.attack}</div>
                        <div className="text-white/60">ATK</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-blue-400">{pokemon.defense}</div>
                        <div className="text-white/60">DEF</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-green-400">{pokemon.speed}</div>
                        <div className="text-white/60">SPD</div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-white text-sm font-semibold">Abilities:</div>
                      <div className="flex flex-wrap gap-1">
                        {pokemon.abilities.map((ability) => (
                          <Badge key={ability.id} variant="outline" className="text-xs border-white/20 text-white">
                            {ability.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selectedStarter && (
              <div className="text-center">
                <Button
                  onClick={handleConfirm}
                  className="px-8 py-3 text-lg font-bold bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-0 shadow-lg"
                >
                  Start Adventure with {selectedStarter.name}!
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
