"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

interface AnimatedBackgroundProps {
  type: "menu" | "world" | "battle" | "shop"
  className?: string
}

export default function AnimatedBackground({ type, className }: AnimatedBackgroundProps) {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; speed: number }>>(
    [],
  )

  useEffect(() => {
    const particleCount = type === "battle" ? 20 : 10
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      speed: Math.random() * 2 + 0.5,
    }))
    setParticles(newParticles)
  }, [type])

  const getBackgroundStyle = () => {
    switch (type) {
      case "menu":
        return "bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900"
      case "world":
        return "bg-gradient-to-b from-sky-400 via-green-400 to-green-600"
      case "battle":
        return "bg-gradient-to-br from-red-900 via-orange-800 to-yellow-700"
      case "shop":
        return "bg-gradient-to-br from-purple-800 via-pink-700 to-rose-600"
      default:
        return "bg-gradient-to-br from-blue-900 to-purple-900"
    }
  }

  return (
    <div className={cn("fixed inset-0 overflow-hidden", getBackgroundStyle(), className)}>
      {/* Animated particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-white/20 animate-pulse"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            animationDelay: `${particle.id * 0.2}s`,
            animationDuration: `${particle.speed}s`,
          }}
        />
      ))}

      {/* Floating shapes for different screens */}
      {type === "menu" && (
        <>
          <div
            className="absolute top-20 left-10 w-32 h-32 bg-yellow-400/10 rounded-full animate-bounce"
            style={{ animationDelay: "0s", animationDuration: "3s" }}
          />
          <div
            className="absolute bottom-20 right-10 w-24 h-24 bg-blue-400/10 rounded-full animate-bounce"
            style={{ animationDelay: "1s", animationDuration: "4s" }}
          />
          <div
            className="absolute top-1/2 left-1/4 w-16 h-16 bg-green-400/10 rounded-full animate-bounce"
            style={{ animationDelay: "2s", animationDuration: "5s" }}
          />
        </>
      )}

      {type === "world" && (
        <>
          {/* Clouds */}
          <div
            className="absolute top-10 left-0 w-64 h-32 bg-white/30 rounded-full animate-pulse"
            style={{ animationDuration: "4s" }}
          />
          <div
            className="absolute top-20 right-20 w-48 h-24 bg-white/20 rounded-full animate-pulse"
            style={{ animationDelay: "2s", animationDuration: "6s" }}
          />
        </>
      )}

      {type === "battle" && (
        <>
          {/* Lightning effects */}
          <div className="absolute inset-0 bg-yellow-400/5 animate-pulse" style={{ animationDuration: "0.5s" }} />
        </>
      )}
    </div>
  )
}
