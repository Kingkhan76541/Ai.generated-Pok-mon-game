"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Apple, Cherry, Banana } from "lucide-react"
import type { InventoryItem, MapLocation } from "@/lib/game-types"
import { gameEngine } from "@/lib/game-engine"

interface ResourceGatheringProps {
  location: MapLocation
  onComplete: () => void
}

export default function ResourceGathering({ location, onComplete }: ResourceGatheringProps) {
  const [isGathering, setIsGathering] = useState(false)
  const [gatheringProgress, setGatheringProgress] = useState(0)
  const [gatheredItems, setGatheredItems] = useState<InventoryItem[]>([])

  const getResourceIcon = (itemName: string) => {
    if (itemName.toLowerCase().includes("apple")) return <Apple className="h-6 w-6" />
    if (itemName.toLowerCase().includes("banana")) return <Banana className="h-6 w-6" />
    if (itemName.toLowerCase().includes("berry")) return <Cherry className="h-6 w-6" />
    return <span className="text-2xl">🍃</span>
  }

  const handleGather = () => {
    if (!location.items || isGathering) return

    setIsGathering(true)
    setGatheringProgress(0)
    gameEngine.playSound("menu-select")

    // Simulate gathering process
    const gatherInterval = setInterval(() => {
      setGatheringProgress((prev) => {
        const newProgress = prev + 10
        if (newProgress >= 100) {
          clearInterval(gatherInterval)

          // Add items to inventory
          const itemsToGather = location.items || []
          itemsToGather.forEach((item) => {
            gameEngine.addToInventory(item)
          })

          setGatheredItems(itemsToGather)
          setIsGathering(false)
          gameEngine.playSound("pokemon-capture")

          return 100
        }
        return newProgress
      })
    }, 200)
  }

  const handleMakeFood = () => {
    // Simple food crafting system
    const berries = gatheredItems.filter((item) => item.type === "berry")
    const fruits = gatheredItems.filter((item) => item.type === "food")

    if (berries.length >= 2 || fruits.length >= 3) {
      const pokemonFood: InventoryItem = {
        id: "pokemon-food",
        name: "Pokémon Food",
        type: "food",
        quantity: 1,
        description: "Nutritious food that increases Pokémon experience",
        sprite: "/placeholder.svg",
      }

      gameEngine.addToInventory(pokemonFood)
      gameEngine.playSound("menu-select")
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md bg-white shadow-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-balance">
            {getResourceIcon(location.name)}
            {location.name}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isGathering && gatheringProgress === 0 && (
            <>
              <p className="text-muted-foreground">
                You found a {location.name.toLowerCase()}! You can gather resources here.
              </p>

              {location.items && (
                <div className="space-y-2">
                  <h4 className="font-semibold">Available Resources:</h4>
                  <div className="space-y-1">
                    {location.items.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm">{item.name}</span>
                        <Badge variant="secondary">x{item.quantity}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={handleGather} className="flex-1">
                  Gather Resources
                </Button>
                <Button onClick={onComplete} variant="outline">
                  Leave
                </Button>
              </div>
            </>
          )}

          {isGathering && (
            <div className="space-y-4">
              <p className="text-center">Gathering resources...</p>
              <Progress value={gatheringProgress} className="w-full" />
              <div className="text-center text-sm text-muted-foreground">{gatheringProgress}% complete</div>
            </div>
          )}

          {gatheringProgress === 100 && gatheredItems.length > 0 && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="font-semibold text-green-600 mb-2">Resources gathered successfully!</p>
                <div className="space-y-1">
                  {gatheredItems.map((item, index) => (
                    <div key={index} className="flex items-center justify-center gap-2">
                      <span>
                        +{item.quantity} {item.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleMakeFood} variant="outline" className="flex-1 bg-transparent">
                  Make Pokémon Food
                </Button>
                <Button onClick={onComplete} className="flex-1">
                  Continue
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
