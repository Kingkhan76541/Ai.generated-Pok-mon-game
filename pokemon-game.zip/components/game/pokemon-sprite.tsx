"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import type { Pokemon } from "@/lib/game-types"

interface PokemonSpriteProps {
  pokemon: Pokemon
  size?: "small" | "medium" | "large"
  animated?: boolean
  className?: string
  onClick?: () => void
}

export default function PokemonSprite({
  pokemon,
  size = "medium",
  animated = true,
  className,
  onClick,
}: PokemonSpriteProps) {
  const [animationFrame, setAnimationFrame] = useState(0)
  const [isHovered, setIsHovered] = useState(false)

  const sizeClasses = {
    small: "w-16 h-16",
    medium: "w-24 h-24",
    large: "w-32 h-32",
  }

  useEffect(() => {
    if (!animated) return

    const interval = setInterval(() => {
      setAnimationFrame((prev) => (prev + 1) % 4)
    }, 500)

    return () => clearInterval(interval)
  }, [animated])

  const getTypeColor = (type: string) => {
    const colors = {
      fire: "from-red-500 to-orange-500",
      water: "from-blue-500 to-cyan-500",
      grass: "from-green-500 to-emerald-500",
      electric: "from-yellow-400 to-yellow-600",
      normal: "from-gray-400 to-gray-600",
      rock: "from-stone-500 to-stone-700",
      flying: "from-sky-400 to-blue-400",
      psychic: "from-purple-400 to-pink-400",
      ice: "from-cyan-300 to-blue-300",
      dragon: "from-indigo-500 to-purple-600",
      dark: "from-gray-800 to-black",
      steel: "from-slate-400 to-slate-600",
      fairy: "from-pink-300 to-rose-400",
      fighting: "from-red-600 to-orange-600",
      poison: "from-purple-500 to-violet-600",
      bug: "from-green-400 to-lime-500",
      ghost: "from-purple-600 to-indigo-700",
      ground: "from-yellow-600 to-orange-700",
    }
    return colors[type as keyof typeof colors] || "from-gray-400 to-gray-600"
  }

  return (
    <div
      className={cn(
        "relative cursor-pointer transition-all duration-300",
        sizeClasses[size],
        animated && "hover:scale-110",
        isHovered && "scale-105",
        className,
      )}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Pokémon sprite container with cube design */}
      <div
        className={cn(
          "relative w-full h-full rounded-lg overflow-hidden shadow-lg",
          "bg-gradient-to-br",
          getTypeColor(pokemon.type),
          animated && animationFrame % 2 === 0 && "animate-pulse",
        )}
        style={{
          transform: animated ? `translateY(${Math.sin(animationFrame) * 2}px)` : undefined,
        }}
      >
        {/* Cube-style 3D effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
        <div className="absolute bottom-0 right-0 w-full h-full bg-gradient-to-tl from-black/20 to-transparent" />

        {/* Pokémon image */}
        <img
          src={pokemon.sprite || "/placeholder.svg"}
          alt={pokemon.name}
          className="w-full h-full object-cover pixel-art"
          style={{ imageRendering: "pixelated" }}
        />

        {/* Shiny effect */}
        {pokemon.isShiny && (
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-300/30 to-yellow-500/30 animate-pulse" />
        )}

        {/* Level indicator */}
        <div className="absolute top-1 right-1 bg-black/70 text-white text-xs px-1 rounded font-mono">
          Lv.{pokemon.level}
        </div>

        {/* HP bar for battle sprites */}
        {size === "large" && (
          <div className="absolute bottom-2 left-2 right-2">
            <div className="bg-black/50 rounded-full h-2 overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all duration-500",
                  pokemon.hp > pokemon.maxHp * 0.5
                    ? "bg-green-500"
                    : pokemon.hp > pokemon.maxHp * 0.2
                      ? "bg-yellow-500"
                      : "bg-red-500",
                )}
                style={{ width: `${(pokemon.hp / pokemon.maxHp) * 100}%` }}
              />
            </div>
            <div className="text-white text-xs font-mono mt-1">
              {pokemon.hp}/{pokemon.maxHp}
            </div>
          </div>
        )}
      </div>

      {/* Type indicator */}
      <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
        <span
          className={cn(
            "px-2 py-1 rounded-full text-xs font-bold text-white shadow-lg",
            "bg-gradient-to-r",
            getTypeColor(pokemon.type),
          )}
        >
          {pokemon.type.toUpperCase()}
        </span>
      </div>

      {/* Evolution indicator */}
      {pokemon.evolutionLevel && pokemon.level >= pokemon.evolutionLevel && (
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center animate-bounce">
          <span className="text-xs">⚡</span>
        </div>
      )}
    </div>
  )
}
