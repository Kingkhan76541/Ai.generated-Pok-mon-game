"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Heart, Sparkles } from "lucide-react"
import { gameEngine } from "@/lib/game-engine"
import type { GameState } from "@/lib/game-types"
import PokemonCard from "./pokemon-card"

export default function PokemonCenter() {
  const [gameState] = useState<GameState>(gameEngine.getGameState())
  const [isHealing, setIsHealing] = useState(false)
  const [healingComplete, setHealingComplete] = useState(false)

  const handleHealAll = () => {
    setIsHealing(true)
    gameEngine.playSound("menu-select")

    // Simulate healing process
    setTimeout(() => {
      // Heal all Pokémon
      gameState.player.pokemon.forEach((pokemon) => {
        pokemon.hp = pokemon.maxHp
      })

      setIsHealing(false)
      setHealingComplete(true)
      gameEngine.playSound("pokemon-capture") // Healing sound

      setTimeout(() => {
        setHealingComplete(false)
      }, 3000)
    }, 2000)
  }

  const handleBack = () => {
    gameEngine.playSound("menu-select")
    gameEngine.setScreen("world")
  }

  return (
    <div className="w-full h-screen bg-gradient-to-br from-pink-100 via-red-50 to-white flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-red-500 text-white">
        <Button onClick={handleBack} variant="ghost" className="text-white hover:bg-red-600">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to World
        </Button>
        <h1 className="text-2xl font-bold text-balance">Pokémon Center</h1>
        <div className="w-20" />
      </div>

      <div className="flex-1 p-6 space-y-6">
        {/* Nurse Joy */}
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-pink-400 to-red-500 rounded-full flex items-center justify-center">
                <span className="text-2xl">👩‍⚕️</span>
              </div>
              <div>
                <CardTitle className="text-xl text-balance">Nurse Joy</CardTitle>
                <p className="text-muted-foreground">
                  "Welcome to our Pokémon Center! We can heal your Pokémon to perfect health."
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleHealAll}
              disabled={isHealing || healingComplete}
              className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
            >
              {isHealing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Healing your Pokémon...
                </div>
              ) : healingComplete ? (
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Your Pokémon are fully healed!
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4" />
                  Heal All Pokémon (Free)
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Player's Pokémon */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Your Pokémon</h2>

          {gameState.player.pokemon.length === 0 ? (
            <Card className="bg-white/80">
              <CardContent className="p-6 text-center text-muted-foreground">
                You don't have any Pokémon yet!
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {gameState.player.pokemon.map((pokemon, index) => (
                <div key={index} className="relative">
                  <PokemonCard pokemon={pokemon} showStats={true} />

                  {/* Health status indicator */}
                  <div className="absolute top-2 right-2">
                    {pokemon.hp === pokemon.maxHp ? (
                      <Badge className="bg-green-500 text-white">
                        <Heart className="h-3 w-3 mr-1" />
                        Healthy
                      </Badge>
                    ) : pokemon.hp > pokemon.maxHp * 0.5 ? (
                      <Badge className="bg-yellow-500 text-white">
                        <Heart className="h-3 w-3 mr-1" />
                        Injured
                      </Badge>
                    ) : (
                      <Badge className="bg-red-500 text-white">
                        <Heart className="h-3 w-3 mr-1" />
                        Critical
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Services */}
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Additional Services</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Button variant="outline" className="h-12 bg-transparent" disabled>
                <span className="text-sm">PC Storage</span>
              </Button>
              <Button variant="outline" className="h-12 bg-transparent" disabled>
                <span className="text-sm">Trade Center</span>
              </Button>
              <Button variant="outline" className="h-12 bg-transparent" disabled>
                <span className="text-sm">Battle Records</span>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground text-center">Additional services coming soon!</p>
          </CardContent>
        </Card>
      </div>

      {/* Healing animation overlay */}
      {isHealing && (
        <div className="fixed inset-0 bg-pink-500/20 flex items-center justify-center z-50">
          <Card className="bg-white p-8 text-center shadow-2xl">
            <CardContent>
              <div className="animate-pulse mb-4">
                <Heart className="h-16 w-16 text-red-500 mx-auto" />
              </div>
              <p className="text-xl font-bold mb-2">Healing your Pokémon...</p>
              <p className="text-muted-foreground">Please wait a moment</p>
              <div className="mt-4 flex justify-center">
                <div className="animate-spin w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
