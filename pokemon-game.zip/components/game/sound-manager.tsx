"use client"

import { useEffect, useRef } from "react"

interface SoundManagerProps {
  currentScreen: string
}

export default function SoundManager({ currentScreen }: SoundManagerProps) {
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    // Play background music based on current screen
    const playBackgroundMusic = () => {
      if (!audioRef.current) return

      // In a real game, you'd have different music files
      // For now, we'll use a simple tone generator
      try {
        // Create a simple background tone
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)

        // Different tones for different screens
        switch (currentScreen) {
          case "menu":
            oscillator.frequency.setValueAtTime(220, audioContext.currentTime) // A3
            break
          case "world":
            oscillator.frequency.setValueAtTime(330, audioContext.currentTime) // E4
            break
          case "battle":
            oscillator.frequency.setValueAtTime(440, audioContext.currentTime) // A4
            break
          default:
            oscillator.frequency.setValueAtTime(220, audioContext.currentTime)
        }

        gainNode.gain.setValueAtTime(0.02, audioContext.currentTime) // Very low volume
        oscillator.type = "sine"
        oscillator.start()

        // Stop after 2 seconds to avoid continuous sound
        setTimeout(() => {
          oscillator.stop()
        }, 2000)
      } catch (error) {
        console.log("Audio not supported")
      }
    }

    playBackgroundMusic()
  }, [currentScreen])

  return <audio ref={audioRef} loop className="hidden" preload="auto" />
}
