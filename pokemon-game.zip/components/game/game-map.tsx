"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { Player, MapLocation } from "@/lib/game-types"
import { getRandomPokemon } from "@/lib/pokemon-data"
import { gameEngine } from "@/lib/game-engine"

interface GameMapProps {
  player: Player
  onLocationInteract: (location: MapLocation) => void
}

// Define the game world map
const WORLD_MAP: MapLocation[] = [
  // Starting Town
  { id: "home", name: "Home", type: "city", x: 10, y: 10, interactable: true },
  { id: "pokemon-center-1", name: "Pokémon Center", type: "pokemon-center", x: 12, y: 10, interactable: true },
  { id: "shop-1", name: "Poké Mart", type: "shop", x: 8, y: 10, interactable: true },

  // Route 1 - Grass areas
  {
    id: "grass-1",
    name: "Route 1",
    type: "grass",
    x: 10,
    y: 8,
    interactable: true,
    pokemonEncounters: [
      { pokemonId: 12, level: 3, rarity: 60 },
      { pokemonId: 32, level: 4, rarity: 30 },
      { pokemonId: 33, level: 5, rarity: 10 },
    ],
  },
  {
    id: "grass-2",
    name: "Route 1",
    type: "grass",
    x: 12,
    y: 8,
    interactable: true,
    pokemonEncounters: [
      { pokemonId: 12, level: 3, rarity: 60 },
      { pokemonId: 32, level: 4, rarity: 30 },
    ],
  },

  // Berry Forest
  {
    id: "berry-1",
    name: "Oran Berry Bush",
    type: "berry-bush",
    x: 6,
    y: 6,
    interactable: true,
    items: [
      {
        id: "oran-berry",
        name: "Oran Berry",
        type: "berry",
        quantity: 3,
        description: "Restores 10 HP",
        sprite: "/placeholder.svg",
      },
    ],
  },
  {
    id: "berry-2",
    name: "Pecha Berry Bush",
    type: "berry-bush",
    x: 8,
    y: 6,
    interactable: true,
    items: [
      {
        id: "pecha-berry",
        name: "Pecha Berry",
        type: "berry",
        quantity: 2,
        description: "Cures poison",
        sprite: "/placeholder.svg",
      },
    ],
  },

  // Fruit Trees
  {
    id: "apple-tree",
    name: "Apple Tree",
    type: "fruit-tree",
    x: 14,
    y: 6,
    interactable: true,
    items: [
      {
        id: "apple",
        name: "Apple",
        type: "food",
        quantity: 5,
        description: "Sweet and nutritious",
        sprite: "/placeholder.svg",
      },
    ],
  },
  {
    id: "mango-tree",
    name: "Mango Tree",
    type: "fruit-tree",
    x: 16,
    y: 6,
    interactable: true,
    items: [
      {
        id: "mango",
        name: "Mango",
        type: "food",
        quantity: 3,
        description: "Tropical fruit",
        sprite: "/placeholder.svg",
      },
    ],
  },
  {
    id: "banana-tree",
    name: "Banana Tree",
    type: "fruit-tree",
    x: 18,
    y: 6,
    interactable: true,
    items: [
      {
        id: "banana",
        name: "Banana",
        type: "food",
        quantity: 4,
        description: "Energy-rich fruit",
        sprite: "/placeholder.svg",
      },
    ],
  },

  // Jungle Area
  {
    id: "jungle-1",
    name: "Deep Jungle",
    type: "grass",
    x: 6,
    y: 4,
    interactable: true,
    pokemonEncounters: [
      { pokemonId: 7, level: 8, rarity: 40 },
      { pokemonId: 8, level: 12, rarity: 25 },
      { pokemonId: 32, level: 6, rarity: 35 },
    ],
  },
  {
    id: "jungle-2",
    name: "Deep Jungle",
    type: "grass",
    x: 8,
    y: 4,
    interactable: true,
    pokemonEncounters: [
      { pokemonId: 7, level: 8, rarity: 40 },
      { pokemonId: 24, level: 10, rarity: 20 },
      { pokemonId: 31, level: 9, rarity: 40 },
    ],
  },

  // City Area
  { id: "city-center", name: "Cube City", type: "city", x: 15, y: 15, interactable: true },
  { id: "pokemon-center-2", name: "City Pokémon Center", type: "pokemon-center", x: 17, y: 15, interactable: true },
  { id: "shop-2", name: "Department Store", type: "shop", x: 13, y: 15, interactable: true },

  // Gym
  { id: "gym-1", name: "Fire Gym", type: "gym", x: 15, y: 13, interactable: true },

  // More fruit trees
  {
    id: "guava-tree",
    name: "Guava Tree",
    type: "fruit-tree",
    x: 20,
    y: 8,
    interactable: true,
    items: [
      {
        id: "guava",
        name: "Guava",
        type: "food",
        quantity: 3,
        description: "Exotic fruit",
        sprite: "/placeholder.svg",
      },
    ],
  },
  {
    id: "litchi-tree",
    name: "Litchi Tree",
    type: "fruit-tree",
    x: 22,
    y: 8,
    interactable: true,
    items: [
      {
        id: "litchi",
        name: "Litchi",
        type: "food",
        quantity: 2,
        description: "Sweet litchi fruit",
        sprite: "/placeholder.svg",
      },
    ],
  },
]

const GRID_SIZE = 32
const MAP_WIDTH = 25
const MAP_HEIGHT = 20

export default function GameMap({ player, onLocationInteract }: GameMapProps) {
  const [hoveredLocation, setHoveredLocation] = useState<MapLocation | null>(null)
  const [wildEncounter, setWildEncounter] = useState(false)

  const getLocationIcon = (type: string) => {
    switch (type) {
      case "city":
        return "🏘️"
      case "pokemon-center":
        return "🏥"
      case "shop":
        return "🏪"
      case "gym":
        return "🏟️"
      case "grass":
        return "🌱"
      case "berry-bush":
        return "🫐"
      case "fruit-tree":
        return "🌳"
      default:
        return "📍"
    }
  }

  const getLocationColor = (type: string) => {
    switch (type) {
      case "city":
        return "bg-gray-500"
      case "pokemon-center":
        return "bg-red-500"
      case "shop":
        return "bg-blue-500"
      case "gym":
        return "bg-purple-600"
      case "grass":
        return "bg-green-500"
      case "berry-bush":
        return "bg-pink-500"
      case "fruit-tree":
        return "bg-orange-500"
      default:
        return "bg-gray-400"
    }
  }

  const handleLocationClick = (location: MapLocation) => {
    const distance = Math.abs(player.position.x - location.x) + Math.abs(player.position.y - location.y)

    if (distance <= 1) {
      // Player is adjacent to location, can interact
      if (location.type === "grass" && location.pokemonEncounters) {
        // Random encounter check
        if (Math.random() < 0.3) {
          // 30% chance
          const encounters = location.pokemonEncounters
          const randomEncounter = encounters[Math.floor(Math.random() * encounters.length)]
          const wildPokemon = getRandomPokemon(randomEncounter.level)
          gameEngine.startBattle(wildPokemon, true)
          return
        }
      }

      if (location.items) {
        // Collect items
        location.items.forEach((item) => {
          gameEngine.addToInventory(item)
        })
        gameEngine.playSound("menu-select")
      }

      onLocationInteract(location)
    } else {
      // Move player towards location
      const dx = location.x - player.position.x
      const dy = location.y - player.position.y

      if (Math.abs(dx) > Math.abs(dy)) {
        gameEngine.movePlayer(dx > 0 ? "right" : "left")
      } else {
        gameEngine.movePlayer(dy > 0 ? "down" : "up")
      }
    }
  }

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Map grid */}
      <div
        className="absolute inset-0 grid gap-1 p-4"
        style={{
          gridTemplateColumns: `repeat(${MAP_WIDTH}, ${GRID_SIZE}px)`,
          gridTemplateRows: `repeat(${MAP_HEIGHT}, ${GRID_SIZE}px)`,
          transform: `translate(${-player.position.x * (GRID_SIZE + 4) + window.innerWidth / 2}px, ${-player.position.y * (GRID_SIZE + 4) + window.innerHeight / 2}px)`,
          transition: "transform 0.2s ease-out",
        }}
      >
        {/* Render map locations */}
        {WORLD_MAP.map((location) => (
          <div
            key={location.id}
            className={cn(
              "absolute cursor-pointer transition-all duration-200 hover:scale-110",
              "flex items-center justify-center rounded-lg shadow-lg",
              getLocationColor(location.type),
              hoveredLocation?.id === location.id && "ring-2 ring-yellow-400 scale-110",
            )}
            style={{
              left: location.x * (GRID_SIZE + 4),
              top: location.y * (GRID_SIZE + 4),
              width: GRID_SIZE,
              height: GRID_SIZE,
            }}
            onClick={() => handleLocationClick(location)}
            onMouseEnter={() => setHoveredLocation(location)}
            onMouseLeave={() => setHoveredLocation(null)}
          >
            <span className="text-lg">{getLocationIcon(location.type)}</span>
          </div>
        ))}

        {/* Player sprite */}
        <div
          className="absolute z-10 transition-all duration-200 ease-out"
          style={{
            left: player.position.x * (GRID_SIZE + 4),
            top: player.position.y * (GRID_SIZE + 4),
            width: GRID_SIZE,
            height: GRID_SIZE,
          }}
        >
          <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg ring-2 ring-white/50">
            <img
              src={player.sprite || "/placeholder.svg"}
              alt={player.name}
              className="w-6 h-6 pixel-art"
              style={{ imageRendering: "pixelated" }}
            />
          </div>
        </div>
      </div>

      {/* Location info popup */}
      {hoveredLocation && (
        <Card className="fixed top-20 right-4 bg-black/80 backdrop-blur-md border-white/20 text-white z-30 pointer-events-none">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">{getLocationIcon(hoveredLocation.type)}</span>
              <div>
                <div className="font-bold">{hoveredLocation.name}</div>
                <Badge variant="secondary" className="text-xs">
                  {hoveredLocation.type.replace("-", " ").toUpperCase()}
                </Badge>
              </div>
            </div>

            {hoveredLocation.pokemonEncounters && <div className="text-xs text-white/70">Wild Pokémon area</div>}

            {hoveredLocation.items && (
              <div className="text-xs text-white/70">{hoveredLocation.items.length} items available</div>
            )}

            <div className="text-xs text-white/50 mt-1">
              Distance:{" "}
              {Math.abs(player.position.x - hoveredLocation.x) + Math.abs(player.position.y - hoveredLocation.y)}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mini-map */}
      <Card className="fixed bottom-20 right-4 bg-black/80 backdrop-blur-md border-white/20 w-48 h-32">
        <CardContent className="p-2">
          <div className="text-white text-xs font-bold mb-1">Mini Map</div>
          <div className="relative w-full h-24 bg-green-900/50 rounded overflow-hidden">
            {/* Mini map locations */}
            {WORLD_MAP.map((location) => (
              <div
                key={location.id}
                className={cn("absolute w-1 h-1 rounded-full", getLocationColor(location.type))}
                style={{
                  left: `${(location.x / MAP_WIDTH) * 100}%`,
                  top: `${(location.y / MAP_HEIGHT) * 100}%`,
                }}
              />
            ))}

            {/* Player position on mini map */}
            <div
              className="absolute w-2 h-2 bg-white rounded-full ring-1 ring-black"
              style={{
                left: `${(player.position.x / MAP_WIDTH) * 100}%`,
                top: `${(player.position.y / MAP_HEIGHT) * 100}%`,
                transform: "translate(-50%, -50%)",
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
