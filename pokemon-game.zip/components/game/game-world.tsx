"use client"

import { useState, useEffect, useCallback } from "react"
import { gameEngine } from "@/lib/game-engine"
import type { GameState } from "@/lib/game-types"
import GameHUD from "./game-hud"
import GameMap from "./game-map"
import AnimatedBackground from "./animated-background"
import SoundManager from "./sound-manager"

export default function GameWorld() {
  const [gameState, setGameState] = useState<GameState>(gameEngine.getGameState())
  const [isMoving, setIsMoving] = useState(false)

  // Update game state
  useEffect(() => {
    const interval = setInterval(() => {
      setGameState(gameEngine.getGameState())
    }, 100)
    return () => clearInterval(interval)
  }, [])

  // Handle keyboard input for movement
  const handleKeyPress = useCallback(
    (event: KeyboardEvent) => {
      if (isMoving) return

      const key = event.key.toLowerCase()
      let direction: "up" | "down" | "left" | "right" | null = null

      switch (key) {
        case "w":
        case "arrowup":
          direction = "up"
          break
        case "s":
        case "arrowdown":
          direction = "down"
          break
        case "a":
        case "arrowleft":
          direction = "left"
          break
        case "d":
        case "arrowright":
          direction = "right"
          break
      }

      if (direction) {
        setIsMoving(true)
        gameEngine.movePlayer(direction)
        setTimeout(() => setIsMoving(false), 200)
      }
    },
    [isMoving],
  )

  useEffect(() => {
    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [handleKeyPress])

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <AnimatedBackground type="world" />
      <SoundManager currentScreen="world" />

      {/* Game HUD */}
      <GameHUD player={gameState.player} />

      {/* Game Map */}
      <GameMap
        player={gameState.player}
        onLocationInteract={(location) => {
          gameEngine.playSound("menu-select")
          // Handle location interactions
          switch (location.type) {
            case "pokemon-center":
              gameEngine.setScreen("pokemon-center")
              break
            case "shop":
              gameEngine.setScreen("shop")
              break
            case "gym":
              // Start gym battle
              break
            case "berry-bush":
            case "fruit-tree":
              // Collect resources
              break
          }
        }}
      />

      {/* Movement indicator */}
      {isMoving && (
        <div className="fixed bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">Moving...</div>
      )}

      {/* Controls help */}
      <div className="fixed bottom-4 left-4 bg-black/50 text-white px-3 py-2 rounded-lg text-sm">
        <div>WASD / Arrow Keys: Move</div>
        <div>Click: Interact</div>
      </div>
    </div>
  )
}
