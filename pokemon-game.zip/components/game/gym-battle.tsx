"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, ArrowLeft } from "lucide-react"
import { gameEngine } from "@/lib/game-engine"
import { createPokemon } from "@/lib/pokemon-data"
import PokemonSprite from "./pokemon-sprite"

const GYM_LEADERS = [
  {
    id: "fire-gym",
    name: "Blaze",
    type: "fire",
    sprite: "/fire-gym-leader-pixel-art.jpg",
    pokemon: [
      { id: 1, level: 12 }, // Cubemander
      { id: 2, level: 15 }, // Blazecube
    ],
    badge: "Flame Badge",
    reward: {
      currency: 1000,
      experience: 500,
      badge: "flame-badge",
    },
  },
  {
    id: "water-gym",
    name: "Marina",
    type: "water",
    sprite: "/water-gym-leader-pixel-art.jpg",
    pokemon: [
      { id: 4, level: 14 }, // Aquacube
      { id: 5, level: 16 }, // Hydrocube
    ],
    badge: "Wave Badge",
    reward: {
      currency: 1200,
      experience: 600,
      badge: "wave-badge",
    },
  },
]

interface GymBattleProps {
  gymId: string
}

export default function GymBattle({ gymId }: GymBattleProps) {
  const [selectedGym] = useState(GYM_LEADERS.find((gym) => gym.id === gymId) || GYM_LEADERS[0])
  const [battleStarted, setBattleStarted] = useState(false)

  const handleStartBattle = () => {
    setBattleStarted(true)
    gameEngine.playSound("battle-start")

    // Create gym leader's first Pokémon
    const firstPokemon = createPokemon(selectedGym.pokemon[0].id, selectedGym.pokemon[0].level)
    gameEngine.startBattle(firstPokemon, false) // false = not wild, it's a trainer battle
  }

  const handleBack = () => {
    gameEngine.playSound("menu-select")
    gameEngine.setScreen("world")
  }

  if (battleStarted) {
    return null // Battle screen will take over
  }

  return (
    <div className="w-full h-screen bg-gradient-to-br from-orange-400 via-red-500 to-purple-600 flex items-center justify-center">
      <div className="w-full max-w-2xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button onClick={handleBack} variant="outline" className="bg-white/10 border-white/20 text-white">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-white text-balance">Pokémon Gym</h1>
          <div className="w-20" />
        </div>

        {/* Gym Leader Card */}
        <Card className="bg-white/90 backdrop-blur-sm shadow-2xl">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="w-24 h-24 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center">
                <img
                  src={selectedGym.sprite || "/placeholder.svg"}
                  alt={selectedGym.name}
                  className="w-16 h-16 pixel-art"
                  style={{ imageRendering: "pixelated" }}
                />
              </div>
            </div>
            <CardTitle className="text-2xl text-balance">Gym Leader {selectedGym.name}</CardTitle>
            <Badge className="mx-auto w-fit text-lg px-4 py-1">{selectedGym.type.toUpperCase()} TYPE SPECIALIST</Badge>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Challenge description */}
            <div className="text-center space-y-2">
              <p className="text-lg font-semibold">
                "Welcome, challenger! I specialize in {selectedGym.type}-type Pokémon."
              </p>
              <p className="text-muted-foreground">
                "Defeat me to earn the {selectedGym.badge} and prove your worth as a trainer!"
              </p>
            </div>

            {/* Gym Leader's Pokémon */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-center">My Team:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedGym.pokemon.map((pokemon, index) => {
                  const pokemonData = createPokemon(pokemon.id, pokemon.level)
                  return (
                    <Card key={index} className="bg-gradient-to-br from-orange-100 to-red-100">
                      <CardContent className="p-4 text-center space-y-2">
                        <PokemonSprite pokemon={pokemonData} size="medium" />
                        <div>
                          <div className="font-bold">{pokemonData.name}</div>
                          <Badge variant="secondary">Lv.{pokemonData.level}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>

            {/* Rewards */}
            <Card className="bg-yellow-100 border-yellow-300">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-yellow-600" />
                  <span className="font-bold text-yellow-800">Victory Rewards:</span>
                </div>
                <div className="space-y-1 text-sm text-yellow-700">
                  <div>• {selectedGym.badge}</div>
                  <div>• {selectedGym.reward.currency} Coins</div>
                  <div>• {selectedGym.reward.experience} Experience</div>
                  <div>• Gym Leader Recognition</div>
                </div>
              </CardContent>
            </Card>

            {/* Battle button */}
            <div className="text-center">
              <Button
                onClick={handleStartBattle}
                className="px-8 py-4 text-xl font-bold bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white shadow-lg"
              >
                Accept Challenge!
              </Button>
            </div>

            {/* Warning */}
            <div className="text-center text-sm text-muted-foreground">
              <p>Make sure your Pokémon are healed and ready for battle!</p>
              <p>Gym battles are more challenging than wild encounters.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
