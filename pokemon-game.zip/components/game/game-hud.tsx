"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Coins, Heart, Zap, Package, Settings } from "lucide-react"
import { gameEngine } from "@/lib/game-engine"
import type { Player } from "@/lib/game-types"
import { cn } from "@/lib/utils"

interface GameHUDProps {
  player: Player
  className?: string
}

export default function GameHUD({ player, className }: GameHUDProps) {
  const activePokemon = player.activePokemon

  const handleMenuClick = (screen: string) => {
    gameEngine.playSound("menu-select")
    gameEngine.setScreen(screen as any)
  }

  return (
    <div className={cn("fixed top-4 left-4 right-4 z-40 pointer-events-none", className)}>
      <div className="flex justify-between items-start gap-4">
        {/* Player info */}
        <Card className="bg-black/20 backdrop-blur-md border-white/20 pointer-events-auto">
          <CardContent className="p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <img
                  src={player.sprite || "/placeholder.svg"}
                  alt={player.name}
                  className="w-6 h-6 pixel-art"
                  style={{ imageRendering: "pixelated" }}
                />
              </div>
              <div>
                <div className="text-white font-bold text-sm">{player.name}</div>
                <div className="text-white/70 text-xs">Level {player.level}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 text-white text-sm">
              <div className="flex items-center gap-1">
                <Coins className="h-3 w-3 text-yellow-400" />
                <span className="font-mono">{player.currency}</span>
              </div>
              <div className="text-white/70">|</div>
              <div className="text-xs">
                <span className="text-white/70">Skill:</span> {player.skill.name}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Menu buttons */}
        <div className="flex gap-2 pointer-events-auto">
          <Button
            onClick={() => handleMenuClick("inventory")}
            size="sm"
            variant="outline"
            className="bg-black/20 backdrop-blur-md border-white/20 text-white hover:bg-white/20"
          >
            <Package className="h-4 w-4" />
          </Button>
          <Button
            onClick={() => handleMenuClick("shop")}
            size="sm"
            variant="outline"
            className="bg-black/20 backdrop-blur-md border-white/20 text-white hover:bg-white/20"
          >
            <Coins className="h-4 w-4" />
          </Button>
          <Button
            onClick={() => handleMenuClick("menu")}
            size="sm"
            variant="outline"
            className="bg-black/20 backdrop-blur-md border-white/20 text-white hover:bg-white/20"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Active Pokémon info */}
      {activePokemon && (
        <Card className="mt-4 bg-black/20 backdrop-blur-md border-white/20 pointer-events-auto max-w-xs">
          <CardContent className="p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                <img
                  src={activePokemon.sprite || "/placeholder.svg"}
                  alt={activePokemon.name}
                  className="w-6 h-6 pixel-art"
                  style={{ imageRendering: "pixelated" }}
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-white font-bold text-sm">{activePokemon.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    Lv.{activePokemon.level}
                  </Badge>
                </div>
                <Badge className="text-xs mt-1">{activePokemon.type.toUpperCase()}</Badge>
              </div>
            </div>

            {/* HP Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-white">
                <span className="flex items-center gap-1">
                  <Heart className="h-3 w-3 text-red-400" />
                  HP
                </span>
                <span className="font-mono">
                  {activePokemon.hp}/{activePokemon.maxHp}
                </span>
              </div>
              <Progress
                value={(activePokemon.hp / activePokemon.maxHp) * 100}
                className="h-2"
                // Custom color based on HP percentage
                style={{
                  background:
                    activePokemon.hp > activePokemon.maxHp * 0.5
                      ? "#22c55e"
                      : activePokemon.hp > activePokemon.maxHp * 0.2
                        ? "#eab308"
                        : "#ef4444",
                }}
              />
            </div>

            {/* Experience Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-white">
                <span className="flex items-center gap-1">
                  <Zap className="h-3 w-3 text-blue-400" />
                  EXP
                </span>
                <span className="font-mono">
                  {activePokemon.experience}/{activePokemon.experienceToNext}
                </span>
              </div>
              <Progress value={(activePokemon.experience / activePokemon.experienceToNext) * 100} className="h-2" />
            </div>

            {/* Evolution indicator */}
            {activePokemon.evolutionLevel && activePokemon.level >= activePokemon.evolutionLevel && (
              <div className="text-center">
                <Badge className="bg-yellow-500 text-yellow-900 animate-pulse text-xs">Ready to Evolve!</Badge>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
