"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Sword, Shield, Package } from "lucide-react"
import { gameEngine } from "@/lib/game-engine"
import type { GameState, Ability } from "@/lib/game-types"
import PokemonSprite from "./pokemon-sprite"
import AnimatedBackground from "./animated-background"
import { getTypeEffectiveness, getEffectivenessText } from "./type-effectiveness"

export default function BattleScreen() {
  const [gameState, setGameState] = useState<GameState>(gameEngine.getGameState())
  const [selectedAction, setSelectedAction] = useState<"fight" | "catch" | "item" | null>(null)
  const [isAnimating, setIsAnimating] = useState(false)
  const [showCaptureAttempt, setShowCaptureAttempt] = useState(false)
  const [captureSuccess, setCaptureSuccess] = useState(false)

  const battleState = gameState.battleState

  useEffect(() => {
    const interval = setInterval(() => {
      setGameState(gameEngine.getGameState())
    }, 100)
    return () => clearInterval(interval)
  }, [])

  if (!battleState) return null

  const handleAttack = (ability: Ability) => {
    if (!battleState || battleState.turn !== "player" || isAnimating) return

    setIsAnimating(true)
    gameEngine.playSound("battle-start")

    // Calculate damage
    const effectiveness = getTypeEffectiveness(ability.type, battleState.enemyPokemon.type)
    const baseDamage = ability.damage || 0
    const attackStat = battleState.playerPokemon.attack
    const defenseStat = battleState.enemyPokemon.defense
    const damage = Math.floor(((baseDamage * attackStat) / defenseStat) * effectiveness * (0.8 + Math.random() * 0.4))

    // Apply damage
    battleState.enemyPokemon.hp = Math.max(0, battleState.enemyPokemon.hp - damage)

    // Add to battle log
    const effectivenessText = getEffectivenessText(effectiveness)
    battleState.battleLog.push(`${battleState.playerPokemon.name} used ${ability.name}!`)
    if (effectivenessText) {
      battleState.battleLog.push(effectivenessText)
    }
    battleState.battleLog.push(`${battleState.enemyPokemon.name} took ${damage} damage!`)

    // Check if enemy fainted
    if (battleState.enemyPokemon.hp <= 0) {
      battleState.battleLog.push(`${battleState.enemyPokemon.name} fainted!`)
      setTimeout(() => {
        handleBattleWin()
      }, 2000)
    } else {
      // Enemy turn
      battleState.turn = "enemy"
      setTimeout(() => {
        handleEnemyTurn()
      }, 2000)
    }

    setTimeout(() => {
      setIsAnimating(false)
    }, 1500)
  }

  const handleEnemyTurn = () => {
    if (!battleState || battleState.enemyPokemon.hp <= 0) return

    const enemyAbility = battleState.enemyPokemon.abilities[0] // Use first ability
    const effectiveness = getTypeEffectiveness(enemyAbility.type, battleState.playerPokemon.type)
    const baseDamage = enemyAbility.damage || 0
    const attackStat = battleState.enemyPokemon.attack
    const defenseStat = battleState.playerPokemon.defense
    const damage = Math.floor(((baseDamage * attackStat) / defenseStat) * effectiveness * (0.8 + Math.random() * 0.4))

    // Apply damage
    battleState.playerPokemon.hp = Math.max(0, battleState.playerPokemon.hp - damage)

    // Add to battle log
    battleState.battleLog.push(`${battleState.enemyPokemon.name} used ${enemyAbility.name}!`)
    battleState.battleLog.push(`${battleState.playerPokemon.name} took ${damage} damage!`)

    // Check if player Pokémon fainted
    if (battleState.playerPokemon.hp <= 0) {
      battleState.battleLog.push(`${battleState.playerPokemon.name} fainted!`)
      setTimeout(() => {
        handleBattleLoss()
      }, 2000)
    } else {
      // Player turn
      battleState.turn = "player"
    }
  }

  const handleCatch = () => {
    if (!battleState || battleState.turn !== "player" || !battleState.isWild) return

    // Check if player has Pokéballs
    const pokeball = gameState.inventory.find((item) => item.id === "pokeball")
    if (!pokeball || pokeball.quantity <= 0) {
      battleState.battleLog.push("You don't have any Pokéballs!")
      return
    }

    setShowCaptureAttempt(true)
    gameEngine.playSound("pokemon-capture")

    // Calculate capture rate
    const enemyHpPercent = battleState.enemyPokemon.hp / battleState.enemyPokemon.maxHp
    const baseCaptureRate = 0.3 // 30% base rate
    const hpModifier = 1 - enemyHpPercent * 0.5 // Lower HP = higher capture rate
    const levelModifier = Math.max(0.1, 1 - battleState.enemyPokemon.level * 0.02) // Higher level = lower capture rate

    // Player skill bonus
    const skillBonus = gameState.player.skill.effect === "capture_boost" ? 0.15 : 0

    const captureRate = Math.min(0.95, baseCaptureRate + hpModifier + levelModifier + skillBonus)
    const success = Math.random() < captureRate

    setTimeout(() => {
      if (success) {
        setCaptureSuccess(true)
        battleState.battleLog.push(`${battleState.enemyPokemon.name} was caught!`)

        // Add Pokémon to player's team
        const caughtPokemon = { ...battleState.enemyPokemon }
        caughtPokemon.hp = caughtPokemon.maxHp // Heal when caught
        gameState.player.pokemon.push(caughtPokemon)

        setTimeout(() => {
          handleBattleWin()
        }, 2000)
      } else {
        battleState.battleLog.push(`${battleState.enemyPokemon.name} broke free!`)
        setShowCaptureAttempt(false)

        // Enemy turn after failed capture
        battleState.turn = "enemy"
        setTimeout(() => {
          handleEnemyTurn()
        }, 1500)
      }
    }, 2000)

    // Use Pokéball
    gameEngine.useItem("pokeball")
  }

  const handleBattleWin = () => {
    if (!battleState?.rewards) return

    // Award experience and currency
    gameState.player.currency += battleState.rewards.currency
    if (battleState.playerPokemon.hp > 0) {
      battleState.playerPokemon.experience += battleState.rewards.experience

      // Check for level up
      if (battleState.playerPokemon.experience >= battleState.playerPokemon.experienceToNext) {
        battleState.playerPokemon.level++
        battleState.playerPokemon.experience = 0
        battleState.playerPokemon.experienceToNext = battleState.playerPokemon.level * 100
        battleState.playerPokemon.maxHp += 5
        battleState.playerPokemon.hp = battleState.playerPokemon.maxHp
        battleState.battleLog.push(`${battleState.playerPokemon.name} leveled up!`)
      }
    }

    battleState.battleLog.push(`You won the battle!`)
    battleState.battleLog.push(
      `Gained ${battleState.rewards.experience} EXP and ${battleState.rewards.currency} coins!`,
    )

    setTimeout(() => {
      gameEngine.setScreen("world")
    }, 3000)
  }

  const handleBattleLoss = () => {
    battleState.battleLog.push("You lost the battle!")
    setTimeout(() => {
      gameEngine.setScreen("world")
    }, 3000)
  }

  const handleRun = () => {
    if (!battleState.isWild) {
      battleState.battleLog.push("You can't run from a trainer battle!")
      return
    }

    const runChance = 0.7 // 70% chance to run
    if (Math.random() < runChance) {
      battleState.battleLog.push("You ran away safely!")
      setTimeout(() => {
        gameEngine.setScreen("world")
      }, 1500)
    } else {
      battleState.battleLog.push("You couldn't get away!")
      battleState.turn = "enemy"
      setTimeout(() => {
        handleEnemyTurn()
      }, 1500)
    }
  }

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <AnimatedBackground type="battle" />

      <div className="relative z-10 h-full flex flex-col">
        {/* Battle arena */}
        <div className="flex-1 flex items-center justify-between p-8">
          {/* Player Pokémon */}
          <div className="flex flex-col items-center space-y-4">
            <Card className="bg-blue-500/20 backdrop-blur-md border-blue-300/30">
              <CardContent className="p-4">
                <div className="text-center space-y-2">
                  <div className="text-white font-bold">{battleState.playerPokemon.name}</div>
                  <Badge className="bg-blue-600">Lv.{battleState.playerPokemon.level}</Badge>
                  <div className="space-y-1">
                    <Progress
                      value={(battleState.playerPokemon.hp / battleState.playerPokemon.maxHp) * 100}
                      className="h-2 w-32"
                    />
                    <div className="text-white text-xs font-mono">
                      {battleState.playerPokemon.hp}/{battleState.playerPokemon.maxHp} HP
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <div className={`transition-transform duration-500 ${isAnimating ? "scale-110" : ""}`}>
              <PokemonSprite pokemon={battleState.playerPokemon} size="large" animated={true} />
            </div>
          </div>

          {/* VS indicator */}
          <div className="text-center">
            <div className="text-6xl font-bold text-white drop-shadow-2xl animate-pulse">VS</div>
          </div>

          {/* Enemy Pokémon */}
          <div className="flex flex-col items-center space-y-4">
            <Card className="bg-red-500/20 backdrop-blur-md border-red-300/30">
              <CardContent className="p-4">
                <div className="text-center space-y-2">
                  <div className="text-white font-bold">{battleState.enemyPokemon.name}</div>
                  <Badge className="bg-red-600">Lv.{battleState.enemyPokemon.level}</Badge>
                  <div className="space-y-1">
                    <Progress
                      value={(battleState.enemyPokemon.hp / battleState.enemyPokemon.maxHp) * 100}
                      className="h-2 w-32"
                    />
                    <div className="text-white text-xs font-mono">
                      {battleState.enemyPokemon.hp}/{battleState.enemyPokemon.maxHp} HP
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <div className={`transition-transform duration-500 ${isAnimating ? "scale-110" : ""}`}>
              <PokemonSprite pokemon={battleState.enemyPokemon} size="large" animated={true} />
            </div>
          </div>
        </div>

        {/* Battle UI */}
        <div className="bg-black/80 backdrop-blur-md p-4 space-y-4">
          {/* Battle log */}
          <Card className="bg-white/10 border-white/20">
            <CardContent className="p-4">
              <div className="h-24 overflow-y-auto space-y-1">
                {battleState.battleLog.slice(-4).map((log, index) => (
                  <div key={index} className="text-white text-sm">
                    {log}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Action buttons */}
          {battleState.turn === "player" && !isAnimating && (
            <div className="space-y-4">
              {!selectedAction && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <Button
                    onClick={() => setSelectedAction("fight")}
                    className="h-12 bg-red-600 hover:bg-red-700 text-white"
                  >
                    <Sword className="h-4 w-4 mr-2" />
                    Fight
                  </Button>
                  {battleState.isWild && (
                    <Button
                      onClick={() => setSelectedAction("catch")}
                      className="h-12 bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Package className="h-4 w-4 mr-2" />
                      Catch
                    </Button>
                  )}
                  <Button
                    onClick={() => setSelectedAction("item")}
                    className="h-12 bg-blue-600 hover:bg-blue-700 text-white"
                    disabled
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Item
                  </Button>
                  <Button onClick={handleRun} className="h-12 bg-gray-600 hover:bg-gray-700 text-white">
                    Run
                  </Button>
                </div>
              )}

              {selectedAction === "fight" && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-white font-bold">Choose an attack:</h3>
                    <Button onClick={() => setSelectedAction(null)} variant="outline" size="sm">
                      Back
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {battleState.playerPokemon.abilities.map((ability) => (
                      <Button
                        key={ability.id}
                        onClick={() => handleAttack(ability)}
                        className="h-12 bg-purple-600 hover:bg-purple-700 text-white text-left justify-start"
                      >
                        <div>
                          <div className="font-bold">{ability.name}</div>
                          <div className="text-xs opacity-80">
                            {ability.damage} DMG • {ability.type.toUpperCase()}
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {selectedAction === "catch" && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-white font-bold">Throw Pokéball:</h3>
                    <Button onClick={() => setSelectedAction(null)} variant="outline" size="sm">
                      Back
                    </Button>
                  </div>
                  <Button onClick={handleCatch} className="w-full h-12 bg-green-600 hover:bg-green-700 text-white">
                    <Package className="h-4 w-4 mr-2" />
                    Throw Pokéball
                  </Button>
                </div>
              )}
            </div>
          )}

          {battleState.turn === "enemy" && !isAnimating && (
            <div className="text-center text-white">
              <p>Enemy is choosing an attack...</p>
            </div>
          )}
        </div>
      </div>

      {/* Capture attempt animation */}
      {showCaptureAttempt && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="bg-white p-8 text-center">
            <CardContent>
              <div className="animate-bounce mb-4">
                <div className="w-16 h-16 bg-red-500 rounded-full mx-auto flex items-center justify-center">
                  <Package className="h-8 w-8 text-white" />
                </div>
              </div>
              <p className="text-xl font-bold mb-2">{captureSuccess ? "Gotcha!" : "Attempting to catch..."}</p>
              <p className="text-muted-foreground">
                {captureSuccess ? `${battleState.enemyPokemon.name} was caught!` : "The Pokéball is shaking..."}
              </p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
