"use client"

import { useState, useEffect } from "react"
import { gameEngine } from "@/lib/game-engine"
import type { GameState } from "@/lib/game-types"
import MainMenu from "@/components/game/main-menu"
import CharacterSelect from "@/components/game/character-select"
import GameWorld from "@/components/game/game-world"
import BattleScreen from "@/components/game/battle-screen"
import ShopScreen from "@/components/game/shop-screen"
import PokemonCenter from "@/components/game/pokemon-center"
import InventoryScreen from "@/components/game/inventory-screen"

export default function PokemonGame() {
  const [gameState, setGameState] = useState<GameState>(gameEngine.getGameState())

  useEffect(() => {
    // Try to load saved game
    gameEngine.loadGame()
    setGameState(gameEngine.getGameState())

    // Update game state every frame
    const interval = setInterval(() => {
      setGameState(gameEngine.getGameState())
    }, 100)

    return () => clearInterval(interval)
  }, [])

  const renderCurrentScreen = () => {
    switch (gameState.currentScreen) {
      case "menu":
        return <MainMenu />
      case "character-select":
        return <CharacterSelect />
      case "world":
        return <GameWorld />
      case "battle":
        return <BattleScreen />
      case "shop":
        return <ShopScreen />
      case "pokemon-center":
        return <PokemonCenter />
      case "inventory":
        return <InventoryScreen />
      default:
        return <MainMenu />
    }
  }

  return <div className="w-full h-screen bg-background overflow-hidden pixel-art">{renderCurrentScreen()}</div>
}
