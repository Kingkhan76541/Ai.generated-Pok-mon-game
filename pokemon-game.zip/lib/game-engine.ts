import type { GameState, Player, Pokemon, GameScreen, InventoryItem } from "./game-types"
import { createPokemon } from "./pokemon-data"

export class GameEngine {
  private gameState: GameState
  private audioContext: AudioContext | null = null
  private sounds: Map<string, AudioBuffer> = new Map()
  private musicVolume = 0.5
  private sfxVolume = 0.7

  constructor() {
    this.gameState = this.initializeGameState()
    this.initializeAudio()
  }

  private initializeGameState(): GameState {
    const defaultPlayer: Player = {
      id: "player1",
      name: "Trainer",
      level: 1,
      experience: 0,
      currency: 1000,
      pokemon: [],
      activePokemon: null,
      position: { x: 0, y: 0, map: "starting-town" },
      sprite: "/placeholder.svg?height=32&width=32",
      skill: {
        name: "Quick Reflexes",
        description: "Increases capture rate by 10%",
        effect: "capture_boost",
      },
    }

    return {
      player: defaultPlayer,
      currentScreen: "menu",
      inventory: [
        {
          id: "pokeball",
          name: "Pokéball",
          type: "pokeball",
          quantity: 5,
          description: "A device for catching Pokémon",
          sprite: "/placeholder.svg?height=32&width=32",
        },
        {
          id: "potion",
          name: "Potion",
          type: "potion",
          quantity: 3,
          description: "Restores 20 HP",
          sprite: "/placeholder.svg?height=32&width=32",
        },
      ],
      gameSettings: {
        musicVolume: 0.5,
        sfxVolume: 0.7,
        autoSave: true,
      },
    }
  }

  private async initializeAudio() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    } catch (error) {
      console.log("Audio not supported")
    }
  }

  public async playSound(soundName: string) {
    if (!this.audioContext) return

    try {
      // In a real game, you'd load actual audio files
      // For now, we'll create simple synthetic sounds
      const oscillator = this.audioContext.createOscillator()
      const gainNode = this.audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext.destination)

      // Different sounds for different actions
      switch (soundName) {
        case "menu-select":
          oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime)
          break
        case "battle-start":
          oscillator.frequency.setValueAtTime(400, this.audioContext.currentTime)
          break
        case "pokemon-capture":
          oscillator.frequency.setValueAtTime(600, this.audioContext.currentTime)
          break
        case "walk":
          oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime)
          break
        default:
          oscillator.frequency.setValueAtTime(440, this.audioContext.currentTime)
      }

      gainNode.gain.setValueAtTime(this.sfxVolume * 0.1, this.audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.2)

      oscillator.start(this.audioContext.currentTime)
      oscillator.stop(this.audioContext.currentTime + 0.2)
    } catch (error) {
      console.log("Error playing sound:", error)
    }
  }

  public getGameState(): GameState {
    return { ...this.gameState }
  }

  public setScreen(screen: GameScreen) {
    this.gameState.currentScreen = screen
    this.playSound("menu-select")
  }

  public selectStarterPokemon(pokemonId: number) {
    const starter = createPokemon(pokemonId, 5)
    this.gameState.player.pokemon = [starter]
    this.gameState.player.activePokemon = starter
    this.setScreen("world")
  }

  public movePlayer(direction: "up" | "down" | "left" | "right") {
    const { position } = this.gameState.player
    const moveDistance = 1

    switch (direction) {
      case "up":
        position.y = Math.max(0, position.y - moveDistance)
        break
      case "down":
        position.y = Math.min(20, position.y + moveDistance)
        break
      case "left":
        position.x = Math.max(0, position.x - moveDistance)
        break
      case "right":
        position.x = Math.min(20, position.x + moveDistance)
        break
    }

    this.playSound("walk")
  }

  public startBattle(enemyPokemon: Pokemon, isWild = true) {
    if (!this.gameState.player.activePokemon) return

    this.gameState.battleState = {
      playerPokemon: { ...this.gameState.player.activePokemon },
      enemyPokemon: { ...enemyPokemon },
      turn: "player",
      battleLog: [`A wild ${enemyPokemon.name} appeared!`],
      isWild,
      rewards: {
        experience: enemyPokemon.level * 50,
        currency: enemyPokemon.level * 25,
        items: [],
      },
    }

    this.setScreen("battle")
    this.playSound("battle-start")
  }

  public addToInventory(item: InventoryItem) {
    const existingItem = this.gameState.inventory.find((i) => i.id === item.id)
    if (existingItem) {
      existingItem.quantity += item.quantity
    } else {
      this.gameState.inventory.push(item)
    }
  }

  public useItem(itemId: string, target?: Pokemon) {
    const item = this.gameState.inventory.find((i) => i.id === itemId)
    if (!item || item.quantity <= 0) return false

    switch (item.type) {
      case "potion":
        if (target) {
          target.hp = Math.min(target.maxHp, target.hp + 20)
          item.quantity--
          return true
        }
        break
      case "pokeball":
        // Handle in battle system
        item.quantity--
        return true
    }

    return false
  }

  public saveGame() {
    if (typeof window !== "undefined") {
      localStorage.setItem("pokemon-game-save", JSON.stringify(this.gameState))
    }
  }

  public loadGame(): boolean {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("pokemon-game-save")
      if (saved) {
        this.gameState = JSON.parse(saved)
        return true
      }
    }
    return false
  }
}

// Global game engine instance
export const gameEngine = new GameEngine()
