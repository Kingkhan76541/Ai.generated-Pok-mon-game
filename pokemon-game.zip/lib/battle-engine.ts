import type { Pokemon, Ability, BattleState } from "./game-types"
import { getTypeEffectiveness } from "@/components/game/type-effectiveness"

export class BattleEngine {
  static calculateDamage(
    attacker: Pokemon,
    defender: Pokemon,
    ability: Ability,
    criticalHit = false,
  ): {
    damage: number
    effectiveness: number
    isCritical: boolean
  } {
    const baseDamage = ability.damage || 0
    const attackStat = attacker.attack
    const defenseStat = defender.defense
    const effectiveness = getTypeEffectiveness(ability.type, defender.type)

    // Critical hit calculation (5% chance)
    const isCritical = criticalHit || Math.random() < 0.05

    // Damage formula
    let damage = Math.floor(((baseDamage * attackStat) / defenseStat) * effectiveness)

    // Apply critical hit multiplier
    if (isCritical) {
      damage = Math.floor(damage * 1.5)
    }

    // Add random variance (80-120% of calculated damage)
    damage = Math.floor(damage * (0.8 + Math.random() * 0.4))

    // Ensure minimum damage of 1
    damage = Math.max(1, damage)

    return {
      damage,
      effectiveness,
      isCritical,
    }
  }

  static calculateCaptureRate(
    pokemon: Pokemon,
    ballType = "pokeball",
    playerSkillBonus = 0,
  ): {
    captureRate: number
    shakeCount: number
  } {
    // Base capture rates for different ball types
    const ballRates = {
      pokeball: 0.3,
      greatball: 0.5,
      ultraball: 0.7,
      masterball: 1.0,
    }

    const baseCaptureRate = ballRates[ballType as keyof typeof ballRates] || 0.3

    // HP modifier (lower HP = higher capture rate)
    const hpPercent = pokemon.hp / pokemon.maxHp
    const hpModifier = 1 - hpPercent * 0.5

    // Level modifier (higher level = lower capture rate)
    const levelModifier = Math.max(0.1, 1 - pokemon.level * 0.02)

    // Status condition modifiers (not implemented yet)
    const statusModifier = 1.0

    // Calculate final capture rate
    const captureRate = Math.min(
      0.95,
      baseCaptureRate + hpModifier * 0.3 + levelModifier * 0.2 + playerSkillBonus + statusModifier * 0.1,
    )

    // Calculate shake count (0-3 shakes before success/failure)
    const shakeCount = Math.floor(captureRate * 4)

    return {
      captureRate,
      shakeCount,
    }
  }

  static calculateExperienceGain(defeatedPokemon: Pokemon, victorPokemon: Pokemon, isWild = true): number {
    const baseExp = defeatedPokemon.level * 50
    const levelDifference = Math.max(1, defeatedPokemon.level - victorPokemon.level + 5)
    const wildModifier = isWild ? 1.0 : 1.5 // Trainer battles give more EXP

    return Math.floor(baseExp * (levelDifference / 10) * wildModifier)
  }

  static checkForLevelUp(pokemon: Pokemon): boolean {
    if (pokemon.experience >= pokemon.experienceToNext) {
      pokemon.level++
      pokemon.experience -= pokemon.experienceToNext
      pokemon.experienceToNext = pokemon.level * 100

      // Stat increases on level up
      const hpIncrease = Math.floor(Math.random() * 3) + 2 // 2-4 HP
      const statIncrease = Math.floor(Math.random() * 2) + 1 // 1-2 for other stats

      pokemon.maxHp += hpIncrease
      pokemon.hp += hpIncrease // Heal when leveling up
      pokemon.attack += statIncrease
      pokemon.defense += statIncrease
      pokemon.speed += statIncrease

      return true
    }
    return false
  }

  static checkForEvolution(pokemon: Pokemon): boolean {
    return !!(pokemon.evolutionLevel && pokemon.level >= pokemon.evolutionLevel && pokemon.evolutionTarget)
  }

  static getAIMove(pokemon: Pokemon, opponent: Pokemon): Ability {
    // Simple AI: choose the most effective move
    let bestMove = pokemon.abilities[0]
    let bestEffectiveness = 0

    for (const ability of pokemon.abilities) {
      const effectiveness = getTypeEffectiveness(ability.type, opponent.type)
      if (effectiveness > bestEffectiveness) {
        bestEffectiveness = effectiveness
        bestMove = ability
      }
    }

    // Add some randomness (20% chance to use a random move)
    if (Math.random() < 0.2) {
      bestMove = pokemon.abilities[Math.floor(Math.random() * pokemon.abilities.length)]
    }

    return bestMove
  }

  static simulateBattleTurn(
    battleState: BattleState,
    playerAction: {
      type: "attack" | "catch" | "item" | "run"
      ability?: Ability
      item?: string
    },
  ): {
    battleLog: string[]
    battleEnded: boolean
    winner?: "player" | "enemy"
    captured?: boolean
  } {
    const log: string[] = []
    let battleEnded = false
    let winner: "player" | "enemy" | undefined
    let captured = false

    // Player turn
    switch (playerAction.type) {
      case "attack":
        if (playerAction.ability) {
          const result = this.calculateDamage(battleState.playerPokemon, battleState.enemyPokemon, playerAction.ability)

          battleState.enemyPokemon.hp = Math.max(0, battleState.enemyPokemon.hp - result.damage)

          log.push(`${battleState.playerPokemon.name} used ${playerAction.ability.name}!`)
          if (result.isCritical) log.push("Critical hit!")
          if (result.effectiveness > 1) log.push("It's super effective!")
          if (result.effectiveness < 1 && result.effectiveness > 0) log.push("It's not very effective...")
          log.push(`${battleState.enemyPokemon.name} took ${result.damage} damage!`)

          if (battleState.enemyPokemon.hp <= 0) {
            log.push(`${battleState.enemyPokemon.name} fainted!`)
            battleEnded = true
            winner = "player"
          }
        }
        break

      case "catch":
        if (battleState.isWild) {
          const captureResult = this.calculateCaptureRate(battleState.enemyPokemon)
          const success = Math.random() < captureResult.captureRate

          log.push(`Threw a Pokéball at ${battleState.enemyPokemon.name}!`)

          if (success) {
            log.push(`${battleState.enemyPokemon.name} was caught!`)
            battleEnded = true
            captured = true
            winner = "player"
          } else {
            log.push(`${battleState.enemyPokemon.name} broke free!`)
          }
        }
        break

      case "run":
        if (battleState.isWild) {
          const runSuccess = Math.random() < 0.7 // 70% success rate
          if (runSuccess) {
            log.push("Got away safely!")
            battleEnded = true
          } else {
            log.push("Couldn't get away!")
          }
        } else {
          log.push("You can't run from a trainer battle!")
        }
        break
    }

    // Enemy turn (if battle continues)
    if (!battleEnded && battleState.enemyPokemon.hp > 0) {
      const enemyMove = this.getAIMove(battleState.enemyPokemon, battleState.playerPokemon)
      const result = this.calculateDamage(battleState.enemyPokemon, battleState.playerPokemon, enemyMove)

      battleState.playerPokemon.hp = Math.max(0, battleState.playerPokemon.hp - result.damage)

      log.push(`${battleState.enemyPokemon.name} used ${enemyMove.name}!`)
      if (result.isCritical) log.push("Critical hit!")
      log.push(`${battleState.playerPokemon.name} took ${result.damage} damage!`)

      if (battleState.playerPokemon.hp <= 0) {
        log.push(`${battleState.playerPokemon.name} fainted!`)
        battleEnded = true
        winner = "enemy"
      }
    }

    return {
      battleLog: log,
      battleEnded,
      winner,
      captured,
    }
  }
}
