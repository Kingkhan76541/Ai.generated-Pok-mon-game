export interface Pokemon {
  id: number
  name: string
  type: PokemonType
  level: number
  hp: number
  maxHp: number
  attack: number
  defense: number
  speed: number
  experience: number
  experienceToNext: number
  abilities: Ability[]
  sprite: string
  sound: string
  isShiny?: boolean
  evolutionLevel?: number
  evolutionTarget?: string
}

export interface Ability {
  id: string
  name: string
  description: string
  damage?: number
  type: PokemonType
  cost: number
}

export type PokemonType =
  | "fire"
  | "water"
  | "grass"
  | "electric"
  | "normal"
  | "rock"
  | "ground"
  | "flying"
  | "psychic"
  | "ice"
  | "dragon"
  | "dark"
  | "steel"
  | "fairy"
  | "fighting"
  | "poison"
  | "bug"
  | "ghost"

export interface Player {
  id: string
  name: string
  level: number
  experience: number
  currency: number
  pokemon: Pokemon[]
  activePokemon: Pokemon | null
  position: Position
  sprite: string
  skill: PlayerSkill
}

export interface PlayerSkill {
  name: string
  description: string
  effect: string
}

export interface Position {
  x: number
  y: number
  map: string
}

export interface GameState {
  player: Player
  currentScreen: GameScreen
  inventory: InventoryItem[]
  gameSettings: GameSettings
  battleState?: BattleState
}

export type GameScreen = "menu" | "character-select" | "world" | "battle" | "shop" | "pokemon-center" | "inventory"

export interface InventoryItem {
  id: string
  name: string
  type: "pokeball" | "potion" | "berry" | "evolution-shard" | "food"
  quantity: number
  description: string
  sprite: string
}

export interface BattleState {
  playerPokemon: Pokemon
  enemyPokemon: Pokemon
  turn: "player" | "enemy"
  battleLog: string[]
  isWild: boolean
  rewards?: BattleRewards
}

export interface BattleRewards {
  experience: number
  currency: number
  items: InventoryItem[]
}

export interface GameSettings {
  musicVolume: number
  sfxVolume: number
  autoSave: boolean
}

export interface MapLocation {
  id: string
  name: string
  type: "grass" | "city" | "gym" | "pokemon-center" | "shop" | "berry-bush" | "fruit-tree"
  x: number
  y: number
  interactable: boolean
  pokemonEncounters?: PokemonEncounter[]
  items?: InventoryItem[]
}

export interface PokemonEncounter {
  pokemonId: number
  level: number
  rarity: number // 0-100
}
