import type { Pokemon, Ability } from "./game-types"

export const POKEMON_ABILITIES: Record<string, Ability> = {
  // Fire abilities
  ember: { id: "ember", name: "Ember", description: "A small flame attack", damage: 25, type: "fire", cost: 10 },
  flamethrower: {
    id: "flamethrower",
    name: "Flamethrower",
    description: "Intense fire blast",
    damage: 45,
    type: "fire",
    cost: 20,
  },
  fireBlast: {
    id: "fireBlast",
    name: "Fire Blast",
    description: "Devastating fire attack",
    damage: 70,
    type: "fire",
    cost: 35,
  },

  // Water abilities
  waterGun: {
    id: "waterGun",
    name: "Water Gun",
    description: "Shoots pressurized water",
    damage: 25,
    type: "water",
    cost: 10,
  },
  bubble: {
    id: "bubble",
    name: "Bubble",
    description: "Bubble attack that may slow",
    damage: 20,
    type: "water",
    cost: 8,
  },
  hydroPump: {
    id: "hydroPump",
    name: "Hydro Pump",
    description: "Powerful water blast",
    damage: 65,
    type: "water",
    cost: 30,
  },

  // Grass abilities
  vineWhip: { id: "vineWhip", name: "Vine Whip", description: "Whips with vines", damage: 25, type: "grass", cost: 10 },
  razorLeaf: {
    id: "razorLeaf",
    name: "Razor Leaf",
    description: "Sharp leaf projectiles",
    damage: 35,
    type: "grass",
    cost: 15,
  },
  solarBeam: {
    id: "solarBeam",
    name: "Solar Beam",
    description: "Concentrated solar energy",
    damage: 80,
    type: "grass",
    cost: 40,
  },

  // Electric abilities
  thunderShock: {
    id: "thunderShock",
    name: "Thunder Shock",
    description: "Electric shock attack",
    damage: 25,
    type: "electric",
    cost: 10,
  },
  thunderbolt: {
    id: "thunderbolt",
    name: "Thunderbolt",
    description: "Powerful electric attack",
    damage: 50,
    type: "electric",
    cost: 25,
  },
  thunder: {
    id: "thunder",
    name: "Thunder",
    description: "Devastating lightning strike",
    damage: 75,
    type: "electric",
    cost: 35,
  },

  // Normal abilities
  tackle: { id: "tackle", name: "Tackle", description: "Basic physical attack", damage: 20, type: "normal", cost: 5 },
  scratch: { id: "scratch", name: "Scratch", description: "Claw attack", damage: 22, type: "normal", cost: 6 },
  hyperBeam: {
    id: "hyperBeam",
    name: "Hyper Beam",
    description: "Ultimate normal attack",
    damage: 90,
    type: "normal",
    cost: 45,
  },
}

export const POKEMON_DATABASE: Record<
  number,
  Omit<Pokemon, "level" | "hp" | "maxHp" | "experience" | "experienceToNext">
> = {
  // Fire Type Pokémon
  1: {
    id: 1,
    name: "Cubemander",
    type: "fire",
    attack: 52,
    defense: 43,
    speed: 65,
    abilities: [POKEMON_ABILITIES.ember, POKEMON_ABILITIES.scratch],
    sprite: "/red-orange-fire-cube-salamander-pixel-art.jpg",
    sound: "fire-roar.mp3",
    evolutionLevel: 16,
    evolutionTarget: "Blazecube",
  },
  2: {
    id: 2,
    name: "Blazecube",
    type: "fire",
    attack: 64,
    defense: 58,
    speed: 80,
    abilities: [POKEMON_ABILITIES.flamethrower, POKEMON_ABILITIES.ember],
    sprite: "/bright-red-fire-cube-dragon-evolved-pixel-art.jpg",
    sound: "fire-blast.mp3",
    evolutionLevel: 36,
    evolutionTarget: "Infernocube",
  },
  3: {
    id: 3,
    name: "Infernocube",
    type: "fire",
    attack: 84,
    defense: 78,
    speed: 100,
    abilities: [POKEMON_ABILITIES.fireBlast, POKEMON_ABILITIES.flamethrower],
    sprite: "/blazing-red-orange-fire-cube-dragon-final-evolutio.jpg",
    sound: "inferno-roar.mp3",
  },

  // Water Type Pokémon
  4: {
    id: 4,
    name: "Aquacube",
    type: "water",
    attack: 48,
    defense: 65,
    speed: 43,
    abilities: [POKEMON_ABILITIES.waterGun, POKEMON_ABILITIES.tackle],
    sprite: "/blue-water-cube-turtle-pixel-art.jpg",
    sound: "water-splash.mp3",
    evolutionLevel: 16,
    evolutionTarget: "Hydrocube",
  },
  5: {
    id: 5,
    name: "Hydrocube",
    type: "water",
    attack: 63,
    defense: 80,
    speed: 58,
    abilities: [POKEMON_ABILITIES.bubble, POKEMON_ABILITIES.waterGun],
    sprite: "/deep-blue-water-cube-turtle-evolved-pixel-art.jpg",
    sound: "water-burst.mp3",
    evolutionLevel: 36,
    evolutionTarget: "Tsunamicube",
  },
  6: {
    id: 6,
    name: "Tsunamicube",
    type: "water",
    attack: 83,
    defense: 100,
    speed: 78,
    abilities: [POKEMON_ABILITIES.hydroPump, POKEMON_ABILITIES.bubble],
    sprite: "/ocean-blue-water-cube-turtle-final-evolution-pixel.jpg",
    sound: "tsunami-wave.mp3",
  },

  // Grass Type Pokémon
  7: {
    id: 7,
    name: "Leafcube",
    type: "grass",
    attack: 49,
    defense: 49,
    speed: 45,
    abilities: [POKEMON_ABILITIES.vineWhip, POKEMON_ABILITIES.tackle],
    sprite: "/green-leaf-grass-cube-plant-pixel-art.jpg",
    sound: "leaf-rustle.mp3",
    evolutionLevel: 16,
    evolutionTarget: "Ivycube",
  },
  8: {
    id: 8,
    name: "Ivycube",
    type: "grass",
    attack: 62,
    defense: 63,
    speed: 60,
    abilities: [POKEMON_ABILITIES.razorLeaf, POKEMON_ABILITIES.vineWhip],
    sprite: "/forest-green-ivy-cube-plant-evolved-pixel-art.jpg",
    sound: "vine-whip.mp3",
    evolutionLevel: 32,
    evolutionTarget: "Venomcube",
  },
  9: {
    id: 9,
    name: "Venomcube",
    type: "grass",
    attack: 82,
    defense: 83,
    speed: 80,
    abilities: [POKEMON_ABILITIES.solarBeam, POKEMON_ABILITIES.razorLeaf],
    sprite: "/dark-green-venomous-cube-plant-final-evolution-pix.jpg",
    sound: "solar-beam.mp3",
  },

  // Electric Type Pokémon
  10: {
    id: 10,
    name: "Sparkcube",
    type: "electric",
    attack: 55,
    defense: 40,
    speed: 90,
    abilities: [POKEMON_ABILITIES.thunderShock, POKEMON_ABILITIES.tackle],
    sprite: "/yellow-electric-cube-mouse-pixel-art.jpg",
    sound: "electric-zap.mp3",
    evolutionLevel: 22,
    evolutionTarget: "Voltcube",
  },
  11: {
    id: 11,
    name: "Voltcube",
    type: "electric",
    attack: 90,
    defense: 55,
    speed: 110,
    abilities: [POKEMON_ABILITIES.thunderbolt, POKEMON_ABILITIES.thunderShock],
    sprite: "/bright-yellow-electric-cube-mouse-evolved-pixel-ar.jpg",
    sound: "thunderbolt.mp3",
  },

  // Normal Type Pokémon
  12: {
    id: 12,
    name: "Normalcube",
    type: "normal",
    attack: 45,
    defense: 35,
    speed: 75,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/brown-normal-cube-cat-pixel-art.jpg",
    sound: "normal-cry.mp3",
  },
  13: {
    id: 13,
    name: "Speedcube",
    type: "normal",
    attack: 70,
    defense: 60,
    speed: 105,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/tan-fast-normal-cube-cheetah-pixel-art.jpg",
    sound: "speed-dash.mp3",
  },

  // Rock Type Pokémon
  14: {
    id: 14,
    name: "Rockcube",
    type: "rock",
    attack: 80,
    defense: 100,
    speed: 25,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/gray-stone-rock-cube-golem-pixel-art.jpg",
    sound: "rock-smash.mp3",
  },
  15: {
    id: 15,
    name: "Crystalcube",
    type: "rock",
    attack: 95,
    defense: 115,
    speed: 35,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/crystal-shiny-rock-cube-gem-pixel-art.jpg",
    sound: "crystal-ring.mp3",
  },

  // Flying Type Pokémon
  16: {
    id: 16,
    name: "Skycube",
    type: "flying",
    attack: 60,
    defense: 45,
    speed: 91,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "bird-chirp.mp3",
  },
  17: {
    id: 17,
    name: "Stormcube",
    type: "flying",
    attack: 90,
    defense: 75,
    speed: 101,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "storm-wind.mp3",
  },

  // Psychic Type Pokémon
  18: {
    id: 18,
    name: "Mindcube",
    type: "psychic",
    attack: 35,
    defense: 30,
    speed: 40,
    abilities: [POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "psychic-hum.mp3",
    evolutionLevel: 16,
    evolutionTarget: "Psycube",
  },
  19: {
    id: 19,
    name: "Psycube",
    type: "psychic",
    attack: 50,
    defense: 45,
    speed: 55,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "psychic-wave.mp3",
    evolutionLevel: 36,
    evolutionTarget: "Telepacube",
  },
  20: {
    id: 20,
    name: "Telepacube",
    type: "psychic",
    attack: 75,
    defense: 70,
    speed: 90,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "telepathy.mp3",
  },

  // Ice Type Pokémon
  21: {
    id: 21,
    name: "Icecube",
    type: "ice",
    attack: 50,
    defense: 50,
    speed: 95,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "ice-crack.mp3",
  },
  22: {
    id: 22,
    name: "Frostcube",
    type: "ice",
    attack: 85,
    defense: 85,
    speed: 85,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "frost-wind.mp3",
  },

  // Dragon Type Pokémon
  23: {
    id: 23,
    name: "Dragoncube",
    type: "dragon",
    attack: 100,
    defense: 90,
    speed: 95,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "dragon-roar.mp3",
  },

  // Dark Type Pokémon
  24: {
    id: 24,
    name: "Shadowcube",
    type: "dark",
    attack: 70,
    defense: 65,
    speed: 95,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "shadow-whisper.mp3",
  },
  25: {
    id: 25,
    name: "Voidcube",
    type: "dark",
    attack: 105,
    defense: 90,
    speed: 110,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "void-echo.mp3",
  },

  // Steel Type Pokémon
  26: {
    id: 26,
    name: "Steelcube",
    type: "steel",
    attack: 85,
    defense: 95,
    speed: 50,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "metal-clang.mp3",
  },
  27: {
    id: 27,
    name: "Mechacube",
    type: "steel",
    attack: 110,
    defense: 130,
    speed: 70,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "mecha-whir.mp3",
  },

  // Fairy Type Pokémon
  28: {
    id: 28,
    name: "Fairycube",
    type: "fairy",
    attack: 45,
    defense: 55,
    speed: 85,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "fairy-chime.mp3",
  },
  29: {
    id: 29,
    name: "Angelcube",
    type: "fairy",
    attack: 80,
    defense: 90,
    speed: 100,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.tackle],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "angel-song.mp3",
  },

  // Fighting Type Pokémon
  30: {
    id: 30,
    name: "Fightcube",
    type: "fighting",
    attack: 105,
    defense: 65,
    speed: 85,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "fight-punch.mp3",
  },

  // Poison Type Pokémon
  31: {
    id: 31,
    name: "Toxicube",
    type: "poison",
    attack: 65,
    defense: 60,
    speed: 90,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "poison-bubble.mp3",
  },

  // Bug Type Pokémon
  32: {
    id: 32,
    name: "Bugcube",
    type: "bug",
    attack: 55,
    defense: 50,
    speed: 85,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "bug-buzz.mp3",
  },

  // Ghost Type Pokémon
  33: {
    id: 33,
    name: "Ghostcube",
    type: "ghost",
    attack: 50,
    defense: 45,
    speed: 95,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "ghost-wail.mp3",
  },

  // Ground Type Pokémon
  34: {
    id: 34,
    name: "Earthcube",
    type: "ground",
    attack: 75,
    defense: 85,
    speed: 35,
    abilities: [POKEMON_ABILITIES.tackle, POKEMON_ABILITIES.scratch],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "earth-rumble.mp3",
  },

  // Legendary Pokémon
  35: {
    id: 35,
    name: "Legendcube",
    type: "dragon",
    attack: 150,
    defense: 120,
    speed: 130,
    abilities: [POKEMON_ABILITIES.hyperBeam, POKEMON_ABILITIES.fireBlast, POKEMON_ABILITIES.thunder],
    sprite: "/placeholder.svg?height=64&width=64",
    sound: "legendary-cry.mp3",
  },
}

export function createPokemon(id: number, level = 5): Pokemon {
  const baseData = POKEMON_DATABASE[id]
  if (!baseData) throw new Error(`Pokémon with ID ${id} not found`)

  const maxHp = Math.floor(((baseData.attack + baseData.defense) * level) / 2) + 50
  const experienceToNext = level * 100

  return {
    ...baseData,
    level,
    hp: maxHp,
    maxHp,
    experience: 0,
    experienceToNext,
  }
}

export function getRandomPokemon(level = 5): Pokemon {
  const ids = Object.keys(POKEMON_DATABASE).map(Number)
  const randomId = ids[Math.floor(Math.random() * ids.length)]
  return createPokemon(randomId, level)
}

export function getStarterPokemon(): Pokemon[] {
  return [
    createPokemon(1, 5), // Cubemander
    createPokemon(4, 5), // Aquacube
    createPokemon(7, 5), // Leafcube
  ]
}
